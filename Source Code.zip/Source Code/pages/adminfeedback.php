<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
  background-color: #00BFFF;
  color: white;
 } 
tr:nth-child(even) {
  background-color: #dddddd;
}

.button {
  font: bold 16px Arial;
  text-decoration: none;
  background-color: #EEEEEE;
  color: #333333;
  padding: 2px 6px 2px 6px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC;
}
</style>
</head>
<body>
	<div>
  <div class="header">
	<ul>
	<table style="width:40%">
	 <th><a href = "adminadddoctor.php" style="color: white"> Add Doctor</a></th>
	 <th><a href = "adminviewuser.php" style="color: white">User</a></th>
	 <th><a href = "adminviewdoctor.php" style="color: white">Doctor</a></th>
	 <th><a href = "adminfeedback.php" style="color: white">Feedback</a></th>
	 <th><a href = "adminindex.php?logout='1'" style="color:white;">Logout</a></th>
	</table>
	</ul>
	</div>
	<table>
		<tr>
			<th>Name</th>
			<th>Feedback</th>
			<th>Reply</th>
			<th>Action</th>
		</tr>
		<?php

		$db = mysqli_connect("localhost", "root", "", "registration");

	  	$rows = mysqli_query($db, "SELECT users.username, feedback.feed_id, feedback.feed_descrp, feedback.reply FROM users INNER JOIN feedback ON users.id = feedback.id");

	  	if(isset($_GET['reply'])){
	      $feed_id = $_GET['reply'];
	      $reply = "Your feedback will take action";
	      $db->query("UPDATE feedback SET reply = '$reply' WHERE feed_id = $feed_id") or die($db->error());
	      header("location: adminfeedback.php");
	    }

	    ?>
	    <?php
	      while ($result = mysqli_fetch_array($rows)) { 
	    ?>
		<tr>
			<td><?php echo $result["username"];?></td>
			<td><?php echo $result["feed_descrp"];?></td>
			<td><?php echo $result["reply"];?></td>

			<td><a href="adminfeedback.php?reply=<?php echo $result["feed_id"]; ?>" name="reply" class="button" onclick="return confirm('Are you sure want to reply this feedback?');" type="button">Reply</a></td>
		</tr>
		<?php
	      }
	    ?>
	</table>
</body>
</html>
