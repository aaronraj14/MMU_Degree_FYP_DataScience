<!DOCTYPE html>
<html>
<head>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
  background-color: #00BFFF;
  color: white;
}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
  <div>
	<ul>
	<table style="width:40%">
	 <th><a href = "adminadddoctor.php" style="color: white">Add Doctor</a></th>
	 <th><a href = "adminviewuser.php" style="color: white">User</a></th>
	 <th><a href = "adminviewdoctor.php" style="color: white">Doctor</a></th>
	 <th><a href = "adminfeedback.php" style="color: white">Feedback</a></th>
	 <th><a href = "adminindex.php?logout='1'" style="color: white;">Logout</a></th>
	</table>
	</ul>
	</div>

	<?php

		$db = mysqli_connect("localhost", "root", "", "registration");

	  	$rows = mysqli_query($db, "SELECT * FROM doctor");

	?>

	<h2>View Doctor</h2>
	<table>
		<thead>	
			<tr>
				<th>Name</th>
				<th>Mobile No</th>
				<th>Email ID</th>
				<th>Age</th>
				<th>Gender</th>
				<th>Specialist</th>
			</tr>
		</thead>
		<?php
	      while ($result = mysqli_fetch_array($rows)) { 
	    ?>
			<tbody>
				<tr>
					<td><?php echo $result["username"];?></td>
					<td><?php echo $result["phone"];?></td>
					<td><?php echo $result["email"];?></td>
					<td><?php echo $result["age"];?></td>
					<td><?php echo $result["gender"];?></td>
					<td><?php echo $result["specialize"];?></td>
				</tr>
			</tbody>
		<?php 
			}
		?>
	</table>
</body>
</html>