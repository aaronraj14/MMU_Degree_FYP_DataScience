<?php 
	session_start(); 

?>

<!DOCTYPE html>
<html>
<head>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #FFFAFA;
  text-align: left;
  padding: 8px;
}
th {
  background-color: #000000;
  color: white;
 } 
tr:nth-child(even) {
  background-color: #DCDCDC;
}
</style>
</head>
<body>
	<div>
	<ul>
	<table style="width:40%">
      <th><a href="userheartanalysis.php" style="color: white">Heart Analysis</a></th>
      <th><a href="userviewdoctor.php" style="color: white">View Doctor</a></th>
      <th><a href="userfeedback.php" style="color: white">Feedback</a></th>
      <th><a href="userviewfeedback.php" style="color: white">View Feedback</a></th>
      <th><a href="index.php?logout='1'" style="color:white;">Logout</a></th>
    </table>
    </ul>
    </div>

		<?php  if (isset($_SESSION['username'])) : ?>
			<?php $db = new mysqli('localhost', 'root', '', 'registration'); ?>
			<?php $user = $_SESSION['username']; ?>
			<?php $result = $db->query("SELECT users.username, feedback.feed_descrp, feedback.reply FROM users INNER JOIN feedback ON users.id=feedback.id WHERE users.username='$user' AND users.id=feedback.id"); ?>
			

		<?php endif ?>
	<table>
		<tr>
			<th>Feedback</th>
			<th>Reply</th>
		</tr>

		<?php
	      while ($output = mysqli_fetch_array($result)) { 
	    ?>
		
		<tr>
			<td><?php echo $output["feed_descrp"];?></td>
			<td><?php echo $output["reply"];?></td>
		</tr>

		<?php
	      } 
	    ?>
	</table>

</body>
</html>