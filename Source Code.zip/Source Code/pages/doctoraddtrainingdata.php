<!DOCTYPE html>
<html>
<head>
<style>
	* {
	margin: 0px;
	padding: 0px;
}
body {
	font-size: 120%;
	background: #F8F8FF;
}

.header {
	width: 30%;
	margin: 50px auto 0px;
	color: white;
	background: #4CAF50;
	text-align: center;
	border: 1px solid #4CAF50;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;
	padding: 20px;
}
form, .content {
	width: 30%;
	margin: 0px auto;
	padding: 20px;
	border: 1px solid #4CAF50;
	background: white;
	border-radius: 0px 0px 10px 10px;
}
.input-group {
	margin: 10px 0px 10px 0px;
}

.input-group label {
	display: block;
	text-align: left;
	margin: 3px;
}
.input-group input {
	height: 30px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid gray;
}
.btn {
	padding: 10px;
	font-size: 15px;
	color: white;
	background: #4CAF50;
	border: none;
	border-radius: 5px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #4CAF50; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #4CAF50; 
  border: 1px solid #4CAF50;
  margin-bottom: 20px;
}
</style>
</head>
<body>
	<div>
	<div class="header">
	<ul>
	 <th><a href = "doctoraddtrainingdata.php" style="color: white"> Add Training Data</a></th>
	 <th><a href = "doctorviewtrainingdata.php" style="color: white"> Training Data</a></th>
	 <th><a href = "doctorviewuser.php" style="color: white"> User</a></th>
	</ul>
	</div>
	
	<form method="post" action="doctorlogin.php">
    <h2>Add Training Data</h2>
		<div class="input-group">
			<label>Chest Pain Type</label>
			<input type="text" name="Chest Pain Type">
		</div>
		<div class="input-group">
			<label>Fasting Blood Sugar</label>
			<input type="text" name="Resting Blood Sugar">
		</div>
		<div class="input-group">
			<label>Serum Cholestrol</label>
			<input type="text" name="Serum Cholestrol">
		</div>
		<div class="input-group">
			<label>Fasting Blood Sugar</label>
			<input type="text" name="Fasting Blood Sugar">
		</div>
		<div class="input-group">
			<label>Resting Electrocardiographic</label>
			<input type="text" name="Resting Electrocardiographic">
		</div>
		<div class="input-group">
			<label>Maximum Heart Rate Achieved</label>
			<input type="text" name="Maximum Heart Rate Achieved">
		</div>
		<div class="input-group">
			<label>Exercise Induced Angina</label>
			<input type="text" name="Exercise Induced Angina">
		</div>
		<div class="input-group">
			<label>ST Depression</label>
			<input type="text" name="ST Depression">
		</div>
		<div class="input-group">
			<label>Slope of the peak exercise</label>
			<input type="text" name="Slope of the peak exercise">
		</div>
		<div class="input-group">
			<label>Number of major vessels</label>
			<input type="text" name="Number of major vessels">
		</div>
		<div class="input-group">
			<label>Diaphragm</label>
			<input type="text" name="Diaphragm">
		</div>
	</form>
</body>
</html>