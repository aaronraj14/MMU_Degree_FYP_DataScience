<!DOCTYPE html>
<html>
<head>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
  background-color: #4CAF50;
  color: white;
}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
	<div>
	<ul>
	<table style="width:40%">
	  <th><a href = "doctoraddtrainingdata.php" style="color: white"> Add Training Data</a></th>
	  <th><a href = "doctorviewtrainingdata.php" style="color: white"> Training Data</a></th>
	  <th><a href = "doctorviewuser.php" style="color: white"> User</a></th>
	  <th><a href="doctorindex.php?logout='1'" style="color:white;">Logout</a></th>
	</table> 
	</ul>
	</div>
	<?php

		$db = mysqli_connect("localhost", "root", "", "registration");

	  	$rows = mysqli_query($db, "SELECT * FROM users");

	?>

	<h2>View User</h2>
	<table>
		<thead>	
			<tr>
				<th>Name</th>
				<th>Email ID</th>
			</tr>
		</thead>
		<?php
	      while ($result = mysqli_fetch_array($rows)) { 
	    ?>
			<tbody>
				<tr>
					<td><?php echo $result["username"];?></td>
					<td><?php echo $result["email"];?></td>
				</tr>
			</tbody>
		<?php 
			}
		?>
	</table>
</body>
</html>