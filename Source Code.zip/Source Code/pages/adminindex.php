<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: adminlogin.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: adminlogin.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="../css/adminstyle.css">
</head>
<body>
	<div class="header">
		<h2>Home Page</h2>
	</div>
	<div class="content">
<ul>
	<table>
	 <th><a href = "adminadddoctor.php" style="color: blue"> Add Doctor</a></th>
	 <th><a href = "adminviewuser.php" style="color: blue"> View User</a></th>
	 <th><a href = "adminviewdoctor.php" style="color: blue"> View Doctor</a></th>
	 <th><a href = "adminfeedback.php" style="color: blue">View Feedback</a></th>
	</table>
</ul>

		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in admin information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
			<p> <a href="adminindex.php?logout='1'" style="color: blue;">Logout</a> </p>
		<?php endif ?>
	</div>
		
</body>
</html>