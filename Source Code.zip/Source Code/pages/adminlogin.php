<?php include('adminserver.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/adminstyle.css">
</head>
<body>

	<div class="header">
		<h2>Admin</h2>
	</div>

	<form method="post" action="adminlogin.php">

		<?php include('adminerrors.php'); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username">
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="login_admin">Login</button>
		</div>
    </form>


</body>
</html>


