<?php

   $feed_descrp = "";
   $db = mysqli_connect('localhost', 'root', '', 'registration');
   

 // DECLARATION
	if (isset($_POST['feedback'])) {
		// receive all input values from the form
		$id = mysqli_real_escape_string($db, $_POST['id']);
		$feed_descrp = mysqli_real_escape_string($db, $_POST['feed_descrp']);
		$query = $db->query("INSERT INTO feedback (id, feed_descrp) VALUES('$id','$feed_descrp')");
		if($query){
		   echo "<script>alert('Your feedback sent successfully! Click OK to continue'); window.location = 'userviewfeedback.php';</script>";
	    }

 // form feedback require
		
	}
?>