<?php include('../pages/doctorregisterserver.php');?>
<!DOCTYPE html>
<html>
<head>
<style>
* {
  margin: 0px;
  padding: 0px;
}
body {
  font-size: 120%;
  background: #F8F8FF;
}

.header {
  width: 26%;
  margin: 50px auto 0px;
  color: white;
  background: #00BFFF;
  text-align: center;
  border: 1px solid #00BFFF;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #00BFFF;
}
li {
  float: left;
}
li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

form, .content {
  width: 26%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #00BFFF;
  background: white;
  border-radius: 0px 0px 10px 10px;
}
.input-group {
  margin: 10px 0px 10px 0px;
}

.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;
}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #00BFFF;
  border: none;
  border-radius: 5px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #00BFFF; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #00BFFF;
  margin-bottom: 20px;
}
</style>
</head>
<body>
	<div>
  <div class="header">
	<ul>
	 <li><a href = "adminadddoctor.php"> Add Doctor</a></li>
	 <li><a href = "adminviewuser.php">User</a></li>
	 <li><a href = "adminviewdoctor.php">Doctor</a></li>
	 <li><a href = "adminfeedback.php">Feedback</a></li>
	</ul>
	</div>
	
	<form method="POST" action="doctorregisterserver.php" autocomplete="OFF">
    
    <?php include('adminerrors.php'); ?>

		<h2>Add Doctor</h2>
  <div class="input-group">
  Name:<br>
  <input type="text" name="username" placeholder="Eg: Ali" required><br>
  </div>
  <div class="input-group">
  Password:<br>
  <input type="password" name="password" placeholder="Eg: abc" required><br>
  </div>
  <div class="input-group">
  Mobile:<br>
  <input type="text" name="phone" placeholder="Eg: 0144566543" required><br>
  </div>
  <div class="input-group">
  Email ID:<br>
  <input type="email" name="email" placeholder="Eg: ali@gmail.com" required><br>
  </div>
  <div class="input-group">
  Age:<br>
  <input type="number" name="age" placeholder="Eg: 32" required><br>
  </div>
  <div class="input-group">
  Gender:<br>
  <input type="text" name="gender" placeholder="Eg: Male" required><br>
  </div>
  <div class="input-group">
  Specialize:<br>
  <input type="text" name="specialize" placeholder="Eg: Stroke" required><br>
  </div>
  <div class="input-group">
  <button type="submit" class="btn" name="reg_doctor">Register</button>
  </div>
</form>
</ul>
</div>
</body>
</html>
		