<!DOCTYPE html>
<html>
<head>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
  background-color: #4CAF50;
  color: white;
}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
	<div>
	<ul>
	<table style="width: 40%">
	  <th><a href = "doctoraddtrainingdata.php" style="color: white"> Add Training Data</a></th>
	  <th><a href = "doctorviewtrainingdata.php" style="color: white"> Training Data</a></th>
	  <th><a href = "doctorviewuser.php" style="color: white"> User</a></th>
	  <th><a href="doctorindex.php?logout='1'" style="color: white;">Logout</a></th>
	</table> 
	</ul>
	</div>
	
	<form method="post" action="login.php">
    <h2>Training Data</h2>

    
    <table style="width:100%">
		<tr>
			<th>Chest Pain Type</th>
			<th>Resting Blood Sugar</th>
			<th>Serum Cholestrol</th>
			<th>Fasting Blood Sugar</th>
			<th>Resting Electrocardiographic</th>
			<th>Maximum Heart Rate Achieved</th>
			<th>Exercise Induced Angina</th>
			<th>ST Depression</th>
			<th>Slope of the peak exercise</th>
			<th>Blood Pressure</th>
			<th>Number of major vessels</th>
			<th>Diaphragm</th>

		</tr>
	</table>
</form>
</body>
</html>