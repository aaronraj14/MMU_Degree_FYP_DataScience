<?php 

	// variable declaration
	$username = "";
	$password = "";
	$phone = "";
	$email = "";
	$age = "";
	$gender = "";
	$specialize = "";
	$errors = array(); 
	$_SESSION['success'] = "";

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'registration');

	// REGISTER DOCTOR
	if (isset($_POST['reg_doctor'])) {
		// receive all input values from the form
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
        $phone = mysqli_real_escape_string($db, $_POST['phone']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$age = mysqli_real_escape_string($db, $_POST['age']);
		$gender = mysqli_real_escape_string($db, $_POST['gender']);
		$specialize = mysqli_real_escape_string($db, $_POST['specialize']);
		$query = $db->query("INSERT INTO doctor (username, password, phone, email, age, gender, specialize) VALUES('$username','$password','$phone','$email','$age','$gender','$specialize')");

		if($query){
		   echo "<script>alert('Register Successfully! Click OK to continue'); window.location = 'adminviewdoctor.php';</script>";
	    }
    }

			/*
			$_SESSION['username'] = $username;
			$_SESSION['success'] = "Register Success";
			*/
			
   ?>